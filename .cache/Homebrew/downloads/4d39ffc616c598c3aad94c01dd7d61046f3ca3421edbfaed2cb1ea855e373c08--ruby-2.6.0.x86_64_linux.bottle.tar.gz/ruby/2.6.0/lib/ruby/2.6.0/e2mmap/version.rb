module Exception2MessageMapper
  VERSION = "0.1.0"
end
